/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio_bd_u07;

import java.io.*;
import org.neodatis.odb.*;
import java.util.*;

public class CrearBDNeoDatis {
    public static void main(String[] args) {

        ODB odb = ODBFactory.open("departamentos.db"); //Abrimos conexión con el fichero de la BD

        //Creamos 4 objetos Departamento
        Departamento dept1 = new Departamento (1,"Desarrollo","Barcelona",100);
        Departamento dept2 = new Departamento (2,"Marketing","Madrid",50);
        Departamento dept3 = new Departamento (3,"Contabilidad","Sevilla",30);
        Departamento dept4 = new Departamento (4,"Recursos","Valencia",20);

        //Insertamos los objetos en la BD con el método store
        odb.store(dept1);
        odb.store(dept2);
        odb.store(dept3);
        odb.store(dept4);
        
        odb.close(); //Cerramos la conexion
    } 
}

